using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace dotnetapp.Models
{
    public class LoginModel
    {
        [Required(ErrorMessage = "Enter the username")]
        public string Username {get; set;}

        [Required(ErrorMessage = "Enter the password")]
        public string Password{get; set;}
    }
}