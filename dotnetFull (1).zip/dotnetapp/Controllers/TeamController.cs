using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/Team")]
    public class TeamController : ControllerBase
    {
        private ApplicationDbContext _context;

        public TeamController(ApplicationDbContext context)
        {
            _context = context;
        }

        [HttpGet("GetTeams")]
        public async Task<ActionResult<IEnumerable<Team>>> GetTeams()
        {
            var tvalue = _context.Teams.Include("Players").ToList();
            return tvalue;
        }

        [HttpPost("PostTeam")]
        public async Task<ActionResult<Team>> PostTeam(Team team)
        {
            _context.Teams.Add(team);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTeams", team);
        }

        [HttpPut("PutTeam/{id}")]
        public async Task<IActionResult> PutTeam(long id, Team team)
        {
            Console.WriteLine("Inside");
            Console.WriteLine("/n/n/n/n/n/n/n/n/n");
            Console.WriteLine(team.Players == null);
            Team _team = _context.Teams.Find(id);

            if (_team == null)
            {
                return NotFound();
            }

            _team.Name = team.Name;
            _team.MaximumBudget = team.MaximumBudget;

            // foreach(var player in team.Players){
            //     _team.Players.Add(player);
            // }

            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("DeleteTeam/{id}")]
        public async Task<IActionResult> DeleteTeam(long id)
        {
            Team _team = _context.Teams.Find(id);

            if (_team == null)
            {
                return NotFound();
            }

            _context.Teams.Remove(_team);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}