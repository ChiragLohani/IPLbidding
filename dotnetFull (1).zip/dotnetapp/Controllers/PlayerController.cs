using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using dotnetapp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace dotnetapp.Controllers
{
    [ApiController]
    [Route("api/Player")]
    public class PlayerController : ControllerBase
    {
        private ApplicationDbContext _context;

        public PlayerController(ApplicationDbContext context){
            _context = context;
        }

        [HttpGet("GetPlayers")]
        public async Task<ActionResult<IEnumerable<Player>>> GetPlayers(){
            return _context.Players.ToList();
        }

        [HttpPost("PostPlayer")]
        public async Task<ActionResult<Player>> PostPlayer(Player player){
            
            if(player == null){
                return BadRequest();
            }
            
            _context.Players.Add(player);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetPlayers), player);

        }

        [HttpPut("PutPlayer/{id}")]
        public async Task<IActionResult> PutPlayer(long id, Player player){

            Player _player = _context.Players.Find(id);

            if(_player == null){
                return NotFound();
            }

            _player.Name = player.Name;
            _player.Age = player.Age;
            _player.BiddingPrice = player.BiddingPrice;
            _player.Category = player.Category;
            _player.TeamId = player.TeamId;
        
            await _context.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("DeletePlayer/{id}")]
        public async Task<IActionResult> DeletePlayer(long id){
            Player _player = _context.Players.Find(id);

            if(_player == null){
                return NotFound();
            }

            _context.Players.Remove(_player);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}