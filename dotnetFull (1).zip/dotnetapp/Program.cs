using dotnetapp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Text.Json.Serialization;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using System.Buffers;
// using Microsoft.AspNetCore.Mvc.NewtonsoftJson;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<ApplicationDbContext>(d =>
{
    d.UseSqlServer(builder.Configuration.GetConnectionString("Myconnection"));
});

// builder.Services.AddControllersWithViews()
//     .AddNewtonsoftJson(options =>
//     options.SerializerOptions.ReferenceHandler = Newtonsoft.Json.ReferenceHandler.Preserve
// );


// builder.Services.AddMvc()

//         .AddJsonOptions(options => options.SerializerSettings.ContractResolver = new DefaultContractResolver());

builder.Services.AddMvc()
        .AddJsonOptions(options => options.JsonSerializerOptions.PropertyNamingPolicy = null)
        .AddJsonOptions(options=> options.JsonSerializerOptions.ReferenceHandler= ReferenceHandler.IgnoreCycles);
        

// builder.Services.AddMvc()
//         .AddJsonOptions(option=>{
//             option.JsonSerializerOptions.ReferenceHandler= ReferenceHandler.Preserve;
//         });

builder.Services.AddCors(p => p.AddPolicy("corsapp", builder =>
   {
       builder.WithOrigins("*").AllowAnyMethod().AllowAnyHeader();
   }));


builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["Jwt:Issuer"],
        ValidAudience = builder.Configuration["Jwt:Issuer"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:Key"]))
    };
});
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

builder.Services.AddAuthorization();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.UseCors("corsapp");

app.Run();

