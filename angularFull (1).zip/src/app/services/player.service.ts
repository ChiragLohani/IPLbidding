import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Player } from 'src/models/player.model';

@Injectable({
  providedIn: 'root'
})
export class PlayerService {

  baseUrl: string = 'https://ide-abfeaecfbfebad314908277fbcbabfbfeone.premiumproject.examly.io/proxy/8080/api/Player';
  constructor(private httpService : HttpClient) { }

  getPlayers(): Observable<Player[]>{
    return this.httpService.get<Player[]>(this.baseUrl+'/GetPlayers');
  }

  createPlayer(player: Player): Observable<Player>{
    return this.httpService.post<Player>(this.baseUrl+'/PostPlayer',player);
  }

  updatePlayer(playerId: number, player: Player): Observable<Player>{
    return this.httpService.put<Player>(this.baseUrl+`/PutPlayer/${playerId}`,player);
  }

  deletePlayer(playerId: number): Observable<void>{
    return this.httpService.delete<void>(this.baseUrl+`/DeletePlayer/${playerId}`);
  }
}
