import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators'
import { LoginModel } from 'src/models/login-model.model';
import { User } from 'src/models/user.model';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  baseUrl: string ='https://ide-abfeaecfbfebad314908277fbcbabfbfeone.premiumproject.examly.io/proxy/8080/api/users';

  constructor(private httpService : HttpClient) { }

  register(newUser: User): Observable<User>{
    console.log("in register:")
    console.log(newUser);
    return this.httpService.post<any>(this.baseUrl+'/register', newUser);
  }

  login(loginUser: LoginModel): Observable<LoginModel>{
    console.log("entered");
    return this.httpService.post<any>(this.baseUrl+'/login',loginUser).pipe(
      tap(
        response =>{
          if(response && response.Token){

            const tokenPart = response.Token.split('.');
            let payload = JSON.parse(atob(tokenPart[1]));

            localStorage.setItem('userRole', payload.role);

          }
        }
      )
    )
  }

  isLoggedIn(): boolean{
    if(localStorage.getItem('userRole') === 'Admin' || localStorage.getItem('userRole') === 'Organizer'){
      return true;
    }
    return false;
  }

  isAdmin(): boolean{
    return localStorage.getItem('userRole') === "Admin";
  }

  isOrganizer(): boolean{
    return localStorage.getItem('userRole') === "Organizer";
  }

  logout(){
    localStorage.clear();
    
  }
}
