import { TestBed } from '@angular/core/testing';
import { PlayerService } from './player.service';
import { Player } from 'src/models/player.model';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

describe('PlayerService Integration Tests', () => {
  let service: PlayerService;
  let httpMock: HttpTestingController;


  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [PlayerService]
    });
    service = TestBed.inject(PlayerService);
    httpMock = TestBed.inject(HttpTestingController);

    jasmine.DEFAULT_TIMEOUT_INTERVAL = 3000;

  });

  afterEach(() => {
    httpMock.verify();
  });

  fit('Week7_Day1_PlayerService_should_be_created', () => {
    expect(service).toBeTruthy();
  });

  fit('Week7_Day1_PlayerService_should_get_all_players', () => {
    const mockPlayers: Player[] = [
      { Id: 1, Name: 'Player 1', Age: 25, Category: 'Category 1', BiddingPrice: 100 },
      { Id: 2, Name: 'Player 2', Age: 28, Category: 'Category 2', BiddingPrice: 150 }
    ];

    service['getPlayers']().subscribe((players: Player[]) => {
      expect(players).toEqual(mockPlayers);
      expect(players.length).toBeGreaterThan(0); // Check if any teams are retrieved
    });

    const req = httpMock.expectOne(`${service['baseUrl']}/GetPlayers`);
    expect(req.request.method).toBe('GET');
    req.flush(mockPlayers);
  });

  fit('Week7_Day1_PlayerService_should create a player', () => {
    const mockPlayer: Player = {
      Id: 1,
      Name: 'Test Player',
      Age: 25,
      Category: 'Test Category',
      BiddingPrice: 100
    };

    service['createPlayer'](mockPlayer).subscribe((createdPlayer: Player) => {
      expect(createdPlayer).toEqual(mockPlayer);
    });

    const req = httpMock.expectOne(`${service['baseUrl']}/PostPlayer`);
    expect(req.request.method).toBe('POST');
    req.flush(mockPlayer);
  });

  fit('Week7_Day1_PlayerService_should update a player', () => {
    const playerId = 1;
    const updatedPlayer: Player = {
      Id: playerId,
      Name: 'Updated Player',
      Age: 30,
      Category: 'Updated Category',
      BiddingPrice: 200
    };

    service['updatePlayer'](playerId, updatedPlayer).subscribe((result: Player) => {
      expect(result).toEqual(updatedPlayer);
    });

    const req = httpMock.expectOne(`${service['baseUrl']}/PutPlayer/${playerId}`);
    expect(req.request.method).toBe('PUT');
    req.flush(updatedPlayer);
  });

  fit('Week7_Day1_PlayerService_should delete a player', () => {
    const playerId = 1;

    service['deletePlayer'](playerId).subscribe(() => {
    });

    const req = httpMock.expectOne(`${service['baseUrl']}/DeletePlayer/${playerId}`);
    expect(req.request.method).toBe('DELETE');
    req.flush(null);
  });
});

  // fit('Frontend_AdminService_should_create_a_new_team_via_the_backend', (done: DoneFn) => {
  //   const newTeam: any = { Name: 'New Team', Age: 25, Category: "Batting", BiddingPrice: 120000 };

  //   service['createPlayer'](newTeam).subscribe(
  //     (createdTeam: any) => {
  //       console.log("funny"+createdTeam);

  //       expect(createdTeam).toEqual(newTeam);
  //       done();
  //     },
  //     (error: any) => {
  //       fail('Failed to create team: ' + JSON.stringify(error));
  //     }
  //   );
  // });

  // fit('Frontend_AdminService_should_retrieve_players_from_the_backend', (done: DoneFn) => {
  //   service['getPlayers']().subscribe(
  //     (players: any[]) => {
  //       console.log(players)
  //       expect(players.length).toBeGreaterThan(0); // Check if any teams are retrieved
  //       done();
  //     },
  //     (error: any) => {
  //       fail('Failed to retrieve teams: ' + JSON.stringify(error));
  //     }
  //   );
  // });



  // Write similar test cases for other methods (updateTeam, deleteTeam, getPlayers, createPlayer, updatePlayer, deletePlayer)


