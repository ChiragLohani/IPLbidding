import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Team } from 'src/models/team.model';

@Injectable({
  providedIn: 'root'
})
export class TeamService {
  baseUrl: string = 'https://ide-abfeaecfbfebad314908277fbcbabfbfeone.premiumproject.examly.io/proxy/8080/api/Team';

  constructor(private httpService : HttpClient) { }

  getTeams(): Observable<Team[]>{
    return this.httpService.get<Team[]>(this.baseUrl+'/GetTeams');
  }

  createTeam(team: Team): Observable<Team>{
    return this.httpService.post<Team>(this.baseUrl+'/PostTeam', team);
  }

  updateTeam(teamId: number, team: Team): Observable<Team>{
    return this.httpService.put<Team>(`${this.baseUrl}/PutTeam/${teamId}`,team);
  }

  deleteTeam(teamId: number): Observable<void>{
    return this.httpService.delete<void>(`${this.baseUrl}/DeleteTeam/${teamId}`);
  }
}
