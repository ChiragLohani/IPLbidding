import { Component, OnInit } from '@angular/core';
import { TeamService } from '../services/team.service';
import { PlayerService } from '../services/player.service';
import { Team } from 'src/models/team.model';
import { Player } from 'src/models/player.model';

@Component({
  selector: 'app-organizer',
  templateUrl: './organizer.component.html',
  styleUrls: ['./organizer.component.css']
})
export class OrganizerComponent implements OnInit {

  teams: Team[] = [];
  players: Player[] = [];
  selectedTeam: number;
  unsoldPlayers: Player[] = [];


  constructor(private teamService: TeamService, private playerService: PlayerService) { }

  ngOnInit(): void {
    this.getPlayers();
    this.getTeams();
  }

  getPlayers() {
    this.playerService.getPlayers().subscribe(
      data => {
        this.players = data;
        this.unsoldPlayers = this.players.filter((player) =>
          player.TeamId === null
        );
      }
    )
  }

  getTeams() {
    this.teamService.getTeams().subscribe(
      data => {
        this.teams = data;
      }
    )
    console.log(this.teams.length);
  }

  assignPlayerToTeam(player: Player, selectedTeamId: number) {
    // console.log(selectedTeamId);
    console.log("assign called");
    player.TeamId = selectedTeamId;
    let team: Team = this.teams.find(x => x.Id == selectedTeamId);
    team.MaximumBudget = team.MaximumBudget - player.BiddingPrice;

    if (!team.Players) {
      team.Players = [];
    }
    team.Players.push(player);
    console.log(team);

    for (let i = 0; i < this.unsoldPlayers.length; i++) {
      if (this.unsoldPlayers[i].Id == player.Id) {
        this.unsoldPlayers.splice(i, 1);
      }
    }
    this.teamService.updateTeam(selectedTeamId, team).subscribe(
      () => {
        this.getTeams();
      }
    );
    this.playerService.updatePlayer(player.Id, player).subscribe(
      () => {
        this.getPlayers();
      }
    );

  }

  releasePlayerFromTeam(player: Player, selectedTeamId: number) {
    player.TeamId = null;
    let team: Team = this.teams.find(x => x.Id == selectedTeamId);


    team.MaximumBudget += player.BiddingPrice;
    this.unsoldPlayers.push(player);


    for (let i = 0; i < team.Players.length; i++) {
      if (team.Players[i].Id == player.Id) {
        team.Players.splice(i, 1);
        break;
      }
    }

    this.playerService.updatePlayer(player.Id, player).subscribe(
      () => {
        this.getPlayers();
      }
    );
    this.teamService.updateTeam(selectedTeamId, team).subscribe(
      () => {
        this.getTeams();
      }
    );
  }

}
