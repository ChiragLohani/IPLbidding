import { ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { CreateTeamComponent } from './create-team.component';

describe('CreateTeamComponent', () => {
  let component: CreateTeamComponent;
  let fixture: ComponentFixture<CreateTeamComponent>;
  let debugElement: DebugElement;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateTeamComponent ],
      imports: [ FormsModule, HttpClientModule, RouterTestingModule ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateTeamComponent);
    component = fixture.componentInstance;
    debugElement = fixture.debugElement;
    fixture.detectChanges();

  });

  fit('Week6_Day6_should_create_CreateTeamComponent', () => {
    expect(component).toBeTruthy();
  });

  // fit('Week6_Day6_should submit Create Team form when all fields are valid', fakeAsync(() => {
  //   spyOn(component as any, 'createTeam');

  //   const compiled = fixture.nativeElement;
  //   const playerNameInput = compiled.querySelector('#teamName');
  //   const playerAgeInput = compiled.querySelector('#maximumBudget');
  //   const submitButton = compiled.querySelector('#submit');

  //   // Fill form fields with valid values
  //   playerNameInput.value = 'John Doe';
  //   playerAgeInput.value = '20';

  //   // Trigger input events to update ngModel values
  //   playerNameInput.dispatchEvent(new Event('input'));
  //   playerAgeInput.dispatchEvent(new Event('input'));
  //   submitButton.click();
  //   tick();
  //   fixture.detectChanges();
  //   expect(component['createTeam']).toHaveBeenCalled();
  // }));
});
