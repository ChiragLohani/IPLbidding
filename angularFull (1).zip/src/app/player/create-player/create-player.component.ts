import { Component, OnInit } from '@angular/core';
import { PlayerService } from 'src/app/services/player.service';
import { Player } from 'src/models/player.model';

@Component({
  selector: 'app-create-player',
  templateUrl: './create-player.component.html',
  styleUrls: ['./create-player.component.css']
})
export class CreatePlayerComponent implements OnInit {

  player : Player ={};

  biddingPriceStatus(): string{
    if(this.player.BiddingPrice>5000){
      return 'Good Bidding';
    }
    else if(this.player.BiddingPrice>1000 && this.player.BiddingPrice<5000){
      return 'Low';
    }
    else{
      return 'Too Low';
    }
  }
  constructor(private service: PlayerService) { }

  ngOnInit(): void {
  }

  createPlayer(){
    if(this.player.Age<18){
      alert('Player age must be greater than 18 and less than 99.');
    }
    else{
      this.service.createPlayer(this.player).subscribe();
      alert('Player created successfully');
    }
  }
}
