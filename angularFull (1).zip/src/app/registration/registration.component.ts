import { Component, OnInit } from '@angular/core';
import { User } from 'src/models/user.model';
import { AuthService } from '../services/auth.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  newUserRegistration: User = {
    Username: '',
    Password: '',
    Role: 'Admin'
  };

  confirmPassword : string ='';
  passwordMismatch : boolean = false;
  standard : boolean = true;

  constructor(private service: AuthService) { }

  ngOnInit(): void {
    // console.log('ngonIt called')
  }

  passwordComplexity(){
    let upperCase = false;
    let lowerCase = false;
    let specialChar = false;
    let digit = false;

    for(let i=0;i<this.newUserRegistration.Password.length;i++){
      if(this.newUserRegistration.Password[i]>='A' && this.newUserRegistration.Password[i]<='Z'){
        upperCase = true;
      }
      else if(this.newUserRegistration.Password[i]>='a' && this.newUserRegistration.Password[i]<='z'){
        lowerCase = true;
      }
      else if(this.newUserRegistration.Password[i]>='0' && this.newUserRegistration.Password[i]<='9'){
        digit = true;
      }
      else{
        specialChar = true;
      }
    }

    if(upperCase && lowerCase && digit && specialChar){
      this.standard = true;
      return;
    }
    this.standard = false;
  }

  register(){
      this.service.register(this.newUserRegistration).subscribe();
  }

  mismatchCheck(){
    if(this.confirmPassword == this.newUserRegistration.Password){
      this.passwordMismatch = false;
      return;
    }
    this.passwordMismatch = true;
  }
}

