import { Team } from './team.model';

describe('Team Models', () => {
  fit('Week6_Day3_should_create_Team_instance', () => {
    const team: Team = {
      Name: 'Team A',
      MaximumBudget: 1000000
    };
    expect(team).toBeTruthy();
    expect(team.Name).toBe('Team A');
    expect(team.MaximumBudget).toBe(1000000);
  });

  // it('Week4_Day3_should_create_Team_instance_with_default_values', () => {
  //   const team: Team = {
  //     name: 'Team B',
  //     maximumBudget: 2000000
  //   };
  //   expect(team).toBeTruthy();
  //   expect(team.name).toBe('Team B');
  //   expect(team.maximumBudget).toBe(2000000);
  // });
});
