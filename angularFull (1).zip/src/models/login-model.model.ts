export interface LoginModel{
    Username : string;
    Password : string;
}