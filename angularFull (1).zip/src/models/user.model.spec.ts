import { User } from './user.model';

describe('User Models', () => {
  fit('Week6_Day3_should_create_User_instance', () => {
    const user: User = {
      Id: 1,
      Username: 'admin123',
      Password: 'Test@123',
      Role: 'Admin'
    };
    expect(user).toBeTruthy();
    expect(user.Username).toBe('admin123');
    expect(user.Password).toBe('Test@123');
    expect(user.Role).toBe('Admin');
  });

  // it('Week4_Day3_should_create_User_instance_with_default_values', () => {
  //   const user: User = {
  //     username: 'organizer456',
  //     password: 'anotherPassword',
  //     role: 'ORGANIZER'
  //   };
  //   expect(user).toBeTruthy();
  //   expect(user.username).toBe('organizer456');
  //   expect(user.password).toBe('anotherPassword');
  //   expect(user.role).toBe('ORGANIZER');
  // });
});
